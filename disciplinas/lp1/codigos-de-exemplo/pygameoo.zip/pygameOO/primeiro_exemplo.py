import sys
import pygame

pygame.init()

size = width, height = 800, 600
speed1 = [1, 1]
speed2 = [1, 1]
speed3 = [1, 1]
black = 0, 0, 0

screen = pygame.display.set_mode(size)

ball1 = pygame.image.load("intro_ball.gif")
ball2 = pygame.image.load("intro_ball.gif")
ball3 = pygame.image.load("intro_ball.gif")
ballrect1 = ball1.get_rect()
ballrect2 = ball2.get_rect()
ballrect3 = ball3.get_rect()

while True:

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        elif event.type == pygame.KEYUP:
            sys.exit()

    ballrect1 = ballrect1.move(speed1)
    if ballrect1.left < 0.0 or ballrect1.right > width:
        speed1[0] = -speed1[0]
    if ballrect1.top < 0.0 or ballrect1.bottom > height:
        speed1[1] = -speed1[1]
    ballrect2 = ballrect2.move(speed2)
    if ballrect2.left < 0.0 or ballrect2.right > width:
        speed2[0] = -speed2[0]
    if ballrect2.top < 0.0 or ballrect2.bottom > height:
        speed2[1] = -speed2[1]
    ballrect3 = ballrect3.move(speed3)
    if ballrect3.left < 0.0 or ballrect3.right > width:
        speed3[0] = -speed3[0]
    if ballrect3.top < 0.0 or ballrect3.bottom > height:
        speed3[1] = -speed3[1]

    screen.fill(black)
    screen.blit(ball1, ballrect1)
    screen.blit(ball2, ballrect2)
    screen.blit(ball3, ballrect3)
    pygame.display.flip()
