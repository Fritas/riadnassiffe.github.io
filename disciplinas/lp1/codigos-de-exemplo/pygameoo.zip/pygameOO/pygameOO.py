import pygame
from bola import Bola


class JogoOO:
    BLACK = 0, 0, 0
    screen = None
    lista_de_objetos = []

    def __init__(self, titulo_da_tela, dimensoes_da_tela, profundidade_das_cores=32, flag=None):
        self.ambiente = pygame
        self.ambiente.init()
        self.dimensao = self.largura, self.altura = dimensoes_da_tela
        self.flag = flag
        self.profundidade_das_cores = profundidade_das_cores
        self.titulo_da_tela = titulo_da_tela

    def adicionar_objetos(self, objeto):
        self.lista_de_objetos.append(objeto)

    def atualizar_tela(self):
        if self.screen is not None:
            self.definir_fundo_de_tela()
            for objeto in self.lista_de_objetos:
                self.screen.blit(objeto.retornar_image(), objeto.retornar_surface())
            self.ambiente.display.flip()

    def atualizar_objetos(self):
        for objeto in self.lista_de_objetos:
            objeto.atualizar(self.largura, self.altura)

    def inicializar_screen(self):
        self.ambiente.display.set_caption(self.titulo_da_tela)
        self.screen = self.ambiente.display.set_mode(self.dimensao, self.flag, self.profundidade_das_cores)

    def definir_fundo_de_tela(self):
        self.screen.fill(self.BLACK)

    def tratar_eventos(self):
        for evento in self.ambiente.event.get():
            if evento.type == pygame.QUIT:
                return False
            elif evento.type == pygame.KEYUP:
                for objeto in self.lista_de_objetos:
                    objeto.tratar_evento(evento)
        return True

    def iniciar_jogo(self):
        self.inicializar_screen()
        jogar = True
        while jogar:
            jogar = self.tratar_eventos()
            self.atualizar_objetos()
            self.atualizar_tela()
        self.ambiente.quit()


if __name__ == "__main__":
    jogo = JogoOO("Isso é um teste", (800, 600), 32, pygame.RESIZABLE)
    b1 = Bola(jogo.ambiente, "intro_ball.gif")
    jogo.adicionar_objetos(b1)
    jogo.iniciar_jogo()
