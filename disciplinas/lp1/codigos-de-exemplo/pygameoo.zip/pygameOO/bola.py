from objeto import Objeto


class Bola(Objeto):
    def __init__(self, env, img):
        Objeto.__init__(self, env, img, 5, 6)

    def atualizar(self, width, height):
        self.surface = self.surface.move(self.velocidade)
        if self.surface.top < 0 or self.surface.bottom > height:
            self.velocidade[1] = -self.velocidade[1]
        if self.surface.left < 0.0 or self.surface.right > width:
            self.velocidade[0] = -self.velocidade[0]

    def tratar_evento(self, evento):
        self.velocidade[1] = 2 * self.velocidade[1]
