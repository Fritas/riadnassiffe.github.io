import pygame

pygame.init()
print(pygame.get_error())
som = pygame.mixer.Sound('a.ogg')
som.play()
