"""
"""


class Objeto(object):
    """

    """

    def __init__(self, ambiente, img, vx, vy):
        """

        """
        self.ambiente = ambiente
        self.definir_imagem(img)
        self.definir_velocidade(vx, vy)

    def definir_imagem(self, arquivo):
        """

        """
        self.imagem = self.ambiente.image.load(arquivo)
        self.surface = self.imagem.get_rect()

    def definir_velocidade(self, velocidade_x, velocidade_y):
        """

        """
        self.velocidade = [velocidade_x, velocidade_y]

    def atualizar(self, width, height):
        """

        """
        pass

    def retornar_image(self):
        return self.imagem

    def retornar_surface(self):
        return self.surface
