import pygame

pygame.init()