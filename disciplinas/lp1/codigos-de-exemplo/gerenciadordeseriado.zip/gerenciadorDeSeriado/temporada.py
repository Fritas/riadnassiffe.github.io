class Temporada(object):
    lista_de_episodios = []

    def __init__(self, nome_serie, numero):
        self.nome_serie = nome_serie
        self.numero = numero

    def listar_episodios(self):
        return self.lista_de_episodios

    def procurar_episodio(self, numero):
        for episodio in self.listar_episodios:
            if numero == episodio.numero:
                return episodio
        return None

    def adicionar_episodio(self, numero, nome, descricao, duracao):
        if self.procurar_episodio(numero) is None:
            self.lista_de_episodios.append(numero, nome, descricao, duracao)
            return True
        return False

    def remover_episodio(self, numero):
        episodio = self.procurar_episodio(numero)
        if episodio is not None:
            self.lista_de_episodios.remove(episodio)
            return True
        return False
