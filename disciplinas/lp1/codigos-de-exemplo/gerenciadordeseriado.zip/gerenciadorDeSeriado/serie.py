from temporada import Temporada

class Serie(object):
    lista_de_temporadas = []
    lista_atores = []

    def __init__(self, classificacao_indicativa, titulo, data_inicio, genero, finalizada = False):
        self.classificacao_indicativa = classificacao_indicativa
        self.titulo = titulo.upper()
        self.data_inicio = data_inicio
        self.genero = genero.upper()
        self.finalizada = finalizada

    def procurar_temporada(self, numero):
        for temporada in self.lista_de_temporadas:
            if temporada.numero == numero:
                return temporada
        return None

    def adicionar_temporada(self, numero):
        if(self.procurar_temporada(numero) is None):
            self.lista_de_temporadas.append(Temporada(self.titulo, numero))
            return True
        return False

    def listar_temporadas(self):
        return self.lista_de_temporadas

    def remover_temporada(self, num):
        temporada = self.procurar_temporada(num)
        if temporada is not None:
            self.lista_de_temporadas.remove(temporada)
            return True
        return False

    def adicionar_ator(self, ator):
        if ator not in self.lista_atores:
            self.lista_atores.append(ator)
            return True
        return False

    def remover_ator(self, ator):
        if ator in self.lista_atores:
            self.lista_de_temporadas.remove(ator)
            return True
        return False
