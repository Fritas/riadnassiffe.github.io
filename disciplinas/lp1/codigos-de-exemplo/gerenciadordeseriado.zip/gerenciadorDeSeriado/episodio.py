class Episodio(object):

    def __init__(self, nome, descricao, duracao, temporada):
        self.nome = nome
        self.descricao = descricao
        self.duracao = duracao
        self.temporada = temporada
