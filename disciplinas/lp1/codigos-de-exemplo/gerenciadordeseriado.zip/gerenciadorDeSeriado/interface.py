from gerenciador import GerenciadorDeSeries
import os
import time

def main():
    gerenciador = GerenciadorDeSeries()

    sair = False
    while(not sair):
        print("Menu")
        print("1 - Para adicionar serie ")
        print("2 - Para remover serie ")
        print("3 - Para adicionar temporada ")
        print("4 - Para listar ")
        print("5 - Sair")

        op = int(input("Digite uma opção"))

        if op == 1:
            classificacao_indicativa = input("classificação")
            titulo = input("título")
            data_inicio = input("data inicio")
            genero = input("genero")
            finalizada =  input("andamento")

            if finalizada == "s":
                finalizada = False
            else:
                finalizada = True

            if gerenciador.adicionar_serie(classificacao_indicativa, titulo, data_inicio, genero, finalizada):
                print("Serie adicionada com sucesso!!")
            else:
                print("Ocorreu algum erro ao adicionar a serie")

        elif op == 2:
            titulo = input("Digite o título")

            if gerenciador.remover_serie(titulo):
                print("Serie removida com sucesso!!")
            else:
                print("Ocorreu algum erro ao remover a serie")

        elif op == 3:
            titulo = input("título")
            numero = int(input("numero"))
            if gerenciador.adicionar_temporada(titulo, numero):
                print("Temporada adicionada com sucesso!!")
            else:
                print("Ocorreu algum erro ao adicionar a temporada")
        elif op == 4:
            for serie in gerenciador.lista_de_series:
                print(serie.titulo)
        elif op == 5:
            sair = True
        else:
            print("Opção inválida")

        time.sleep(2)

        os.system("clear")

if __name__ == '__main__':
    main()
