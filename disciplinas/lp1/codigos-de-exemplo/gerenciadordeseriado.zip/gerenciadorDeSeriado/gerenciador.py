from serie import Serie

class GerenciadorDeSeries(object):
    lista_de_series = []

    def salvar(self):

    def buscar_serie(self, titulo):
        for serie in self.lista_de_series:
            if serie.titulo == titulo:
                return serie
        return None

    def adicionar_serie(self, classificacao_indicativa, titulo, data_inicio, genero, finalizada):

        if self.buscar_serie(titulo) is None:
            self.lista_de_series.append(Serie(classificacao_indicativa, titulo, data_inicio, genero, finalizada))
            return True
        return False

    def remover_serie(self, titulo):
        serie = self.buscar_serie(titulo)
        if serie is not None:
            self.lista_de_series.remove(serie)
            return True
        return False

    def listar_serie(self):
        return self.lista_de_series

    def adicionar_temporada(self, titulo, numero):
        serie = self.buscar_serie(titulo)
        if serie is not None:
            return serie.adicionar_temporada(numero)
        return False
