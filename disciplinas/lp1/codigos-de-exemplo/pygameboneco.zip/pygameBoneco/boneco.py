"""

"""
from info201.pygameBoneco.objeto import Objeto
import os

class Boneco(Objeto):
    """
        :param dicionario_de_imagens = {}
        :param lista_de_animacoes = {}
        :param indice_imagem = 0
        :param x_vel = 0
        :param y_vel = 0
        :param indice_imagem = 0
        :param direcao = ''
        :param pos_x = 0
        :param pos_y = 0
        :param STEP_DELAY = 5
        :param step = 0
    """
    dicionario_de_imagens = {}
    dicionario_de_animacoes = {}
    indice_imagem = 0
    x_vel = 0
    y_vel = 0
    indice_imagem = 0
    direcao = ''
    pos_x = 0
    pos_y = 0
    STEP_DELAY = 0
    step = 0
    mexendo = False
    tocando = False

    def __init__(self, ambiente, images, esquerda, direita, cima, baixo):
        """
        :param ambiente:
        :param images:
        :param esquerda:
        :param direita:
        :param cima:
        :param baixo:
        """
        self.esquerda = esquerda
        self.direita = direita
        self.cima = cima
        self.baixo = baixo
        Objeto.__init__(self, ambiente, images, 0, 0, 64, 64)
        self.som_step = ambiente.mixer.Sound('b.wav')

    def ativar_som(self):
        self.som_step.play()

    def desativar_som(self):
        self.som_step.stop()


    def definir_imagem(self, arquivo):
        """
        :param arquivo:
        :return:
        """

        spritesheet = self.ambiente.image.load(arquivo).convert()

        tamanho_l = 30
        tamanho_a = 48
        linha = 0
        andar_baixo = []
        for a in range(3):
            andar_baixo.append(spritesheet.subsurface(((a * tamanho_l + 3, linha * tamanho_a), (tamanho_l, tamanho_a))))
        linha = 1
        andar_esquerda = []
        for a in range(3):
            andar_esquerda.append(
                spritesheet.subsurface(((a * tamanho_l + 1, linha * tamanho_a), (tamanho_l, tamanho_a))))
        linha = 2
        andar_direita = []
        for a in range(3):
            andar_direita.append(spritesheet.subsurface(((a * tamanho_l, linha * tamanho_a), (tamanho_l, tamanho_a))))
        linha = 3
        andar_cima = []
        for a in range(3):
            andar_cima.append(spritesheet.subsurface(((a * tamanho_l + 3, linha * tamanho_a), (tamanho_l, tamanho_a))))

        parado = spritesheet.subsurface(((0, 0), (tamanho_l, tamanho_a)))

        self.image = spritesheet

        self.dicionario_de_animacoes = {'andar_e': andar_esquerda,
                                   'andar_d': andar_direita,
                                   'andar_c': andar_cima,
                                   'andar_b': andar_baixo,
                                   'parado': [parado]}

        self.image = self.dicionario_de_animacoes['parado'][0]
        self.rect = self.image.get_rect(x=100, y=100)

    def animacao(self):
        """

        :return:
        """
        if self.step == self.STEP_DELAY:
            if self.indice_imagem < (len(self.lista_imagens) - 1):
                self.indice_imagem += 1
            else:
                self.indice_imagem = 0

            self.image = self.lista_imagens[self.indice_imagem]
            self.step = 0
        else:
            self.step += 1

        self.rect = self.image.get_rect()
        self.pos_x += self.x_vel
        self.pos_y += self.y_vel
        self.rect.x = self.pos_x
        self.rect.y = self.pos_y

    def verificar_colisao(self):
        blocks_hit_list = self.ambiente.sprite.spritecollide(self, self.lista_de_obstaculos, False)
        for block in blocks_hit_list:
            if self.x_vel > 0:
                self.rect.x = block.rect.left - 32
                self.pos_x = self.rect.x
            elif self.x_vel < 0:
                self.rect.x = block.rect.right
                self.pos_x = self.rect.x
            elif self.y_vel < 0:
                self.rect.y = block.rect.bottom
                self.pos_y = self.rect.y
            else:
                self.rect.y = block.rect.top - 48
                self.pos_y = self.rect.y

    def start_map(self, lista_de_obstaculos):
        self.lista_de_obstaculos = lista_de_obstaculos

    def andar(self):
        """

        :return:
        """

        self.mexendo = True

        if self.direcao == 'esquerda':
            self.x_vel = -2
            self.y_vel = 0
            self.lista_imagens = self.dicionario_de_animacoes['andar_e']
        elif self.direcao == 'direita':
            self.x_vel = 2
            self.y_vel = 0
            self.lista_imagens = self.dicionario_de_animacoes['andar_d']
        elif self.direcao == 'cima':
            self.y_vel = -2
            self.x_vel = 0
            self.lista_imagens = self.dicionario_de_animacoes['andar_c']
        elif self.direcao == 'baixo':
            self.y_vel = 2
            self.x_vel = 0
            self.lista_imagens = self.dicionario_de_animacoes['andar_b']
        else:
            self.x_vel = 0
            self.y_vel = 0
            self.lista_imagens = self.dicionario_de_animacoes['parado']
            self.mexendo = False
        self.animacao()

    def update(self):
        """

        """
        key = self.ambiente.key.get_pressed()
        self.tratar_evento(key)
        self.andar()
        if self.mexendo and not self.tocando:
            self.tocando = True
            self.ativar_som()
        elif self.tocando and not self.mexendo:
            self.tocando = False
            self.desativar_som()

    def tratar_evento(self, key=None, evento=None):
        """
        :param key:
        :param evento:
        :return:
        """
        if key[self.cima]:
            self.direcao = 'cima'
        elif key[self.direita]:
            self.direcao = 'direita'
        elif key[self.esquerda]:
            self.direcao = 'esquerda'
        elif key[self.baixo]:
            self.direcao = 'baixo'
        else:
            self.direcao = "parado"
