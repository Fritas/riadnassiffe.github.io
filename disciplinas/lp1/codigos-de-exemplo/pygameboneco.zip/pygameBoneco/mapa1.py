from info201.pygameBoneco.parede import Parede
from info201.pygameBoneco.grama import Grama
from info201.pygameBoneco.boneco import Boneco


class Mapa1():
    level = [
        "WWWWWWWWWWWWWWWWWWWWW",
        "WGGGGGGGGGGGGGGGGGGGW",
        "WGGGGGGGGGWWWWWWGGGGW",
        "WGGGWWWWGGGGGGGWGGGGW",
        "WGGGWGGGGGGGGWWWWGGGW",
        "WGWWWGGWWWWGGGGGGGGGW",
        "WGGGWGGGGGWGWGGGGGGGW",
        "WGGGWGGGGGWGGGWWWGWGW",
        "WGGGWWWGWWWGGGWGWGGGW",
        "WGGGGGWGGGWGGGWGWGGGW",
        "WWWGGGWGGGWWWWWGWGGGW",
        "WGWGGGGGGWWGGGGGGGGGW",
        "WGWGGGWWWWGGGWWWGGGGW",
        "WGGGGGWGGGGGGGGWGGGGW",
        "WWWWWWWWWWWWWWWWWWWWW",
    ]

    def __init__(self, amb, jogadores):
        self.som_mapa = amb.mixer.Sound("a.ogg")
        self.som_mapa.play()

        self.lista_paredes = amb.sprite.Group()
        self.lista_grama = amb.sprite.Group()
        self.all_sprites_list = amb.sprite.Group()

        self.lista_jogadores = jogadores

        x = y = 0
        for row in self.level:
            for col in row:
                if col == "W":
                    parede = Parede(amb, x, y)
                    self.lista_paredes.add(parede)
                    self.all_sprites_list.add(parede)
                if col == "G":
                    grama = Grama(amb, x, y)
                    self.all_sprites_list.add(grama)
                    self.lista_grama.add(grama)
                x += 32
            y += 32
            x = 0

        for jogador in self.lista_jogadores:
            jogador.start_map(self.lista_paredes)
            self.all_sprites_list.add(jogador)
