from info201.pygameBoneco.objeto import Objeto


class Parede(Objeto):
    """

    """
    def __init__(self, ambiente, pos_x, pos_y):
        """
        :param ambiente:
        :param pos_x:
        :param pos_y:
        """
        Objeto.__init__(self, ambiente, 'parede.png', 0, 0, pos_x, pos_y)

    def update(self):
        pass
