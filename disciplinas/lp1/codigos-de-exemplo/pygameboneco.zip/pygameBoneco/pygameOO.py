import pygame
from info201.pygameBoneco.boneco import Boneco
from info201.pygameBoneco.mapa1 import Mapa1
from info201.pygameBoneco.menu import Menu

class JogoOO(object):
    BLACK = 0, 0, 0
    WHITE = 255, 255, 255
    screen = None
    lista_de_objetos = []

    def __init__(self, titulo_da_tela, dimensoes_da_tela, profundidade_das_cores=32, flag=None):
        self.ambiente = pygame
        self.ambiente.mixer.init()
        self.ambiente.init()
        print(self.ambiente.get_error())
        self.dimensao = self.largura, self.altura = dimensoes_da_tela
        self.flag = flag
        self.profundidade_das_cores = profundidade_das_cores
        self.titulo_da_tela = titulo_da_tela
        self.inicializar_screen()
        # self.lista_jogadores = []
        self.jogadores = []

        self.jogadores.append(
            Boneco(self.ambiente, 'pirate.png', self.ambiente.K_LEFT, self.ambiente.K_RIGHT, self.ambiente.K_UP,
                   self.ambiente.K_DOWN))
        self.jogadores.append(Boneco(self.ambiente, 'kavi.png', self.ambiente.K_a, self.ambiente.K_d, self.ambiente.K_w,
                                     self.ambiente.K_s))

        self.mapa = Mapa1(self.ambiente, self.jogadores)


    def atualizar_tela(self):
        self.mapa.all_sprites_list.draw(self.screen)
        self.ambiente.display.flip()

    def atualizar_objetos(self):
        self.mapa.all_sprites_list.update()
        for jogador in self.jogadores:
            jogador.verificar_colisao()

    def inicializar_screen(self):
        self.ambiente.display.set_caption(self.titulo_da_tela)
        self.screen = self.ambiente.display.set_mode(self.dimensao, self.flag, self.profundidade_das_cores)

    def definir_fundo_de_tela(self):
        self.screen.fill(self.WHITE)

    def tratar_eventos(self):
        for evento in self.ambiente.event.get():
            if evento.type == pygame.QUIT:
                return False
            if evento.type == self.ambiente.MOUSEBUTTONDOWN:
                x, y = evento.pos
                print("Foi clicado na posição", x, y)

        key = self.ambiente.key.get_pressed()
        if key[self.ambiente.K_i]:
            imenu = Menu(self.ambiente, self.screen)

        return True

    def iniciar_jogo(self):
        jogar = True
        self.ambiente.key.set_repeat(100, 200)
        clock = self.ambiente.time.Clock()
        while jogar:
            clock.tick(15)
            jogar = self.tratar_eventos()
            self.atualizar_objetos()
            self.atualizar_tela()
        self.ambiente.quit()


if __name__ == "__main__":
    jogo = JogoOO("Isso é um teste", (800, 600), 32, pygame.RESIZABLE)
    jogo.iniciar_jogo()
