"""
"""
import pygame


class Objeto(pygame.sprite.Sprite):
    """

    """

    def __init__(self, ambiente, img, vx, vy, pos_x=0, pos_y=0):
        """

        """
        super().__init__()
        self.ambiente = ambiente
        self.definir_velocidade(vx, vy)
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.definir_imagem(img)

    def definir_imagem(self, arquivo):
        """

        """
        self.image = self.ambiente.image.load(arquivo)
        self.rect = self.image.get_rect()
        self.rect.x = self.pos_x
        self.rect.y = self.pos_y


    def definir_velocidade(self, velocidade_x, velocidade_y):
        """

        """
        self.velocidade = [velocidade_x, velocidade_y]

    def atualizar(self, width, height):
        pass

    def tratar_evento(self, key=None, evento=None):
        pass

    def retornar_image(self):
        return self.image

    def retornar_surface(self):
        return self.rect
