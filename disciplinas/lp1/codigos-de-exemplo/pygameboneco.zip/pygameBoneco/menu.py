class Menu():

    def __init__(self, amb, screen):
        self.opcoes = ['iniciar jogo', 'salvar', 'sair']
        self.cor_fonte = (255, 255, 255)
        self.cor_seta = (0, 0, 0)
        self.x_pos = 100
        self.y_pos = 100
        self.tamanho_fonte = 70
        self.distancia = 1.4
        self.amb = amb
        self.screen = screen

        # amb.font.init()
        self.myfont = amb.font.Font(None, self.tamanho_fonte)

        self.posicao_seta = 0
        self.desenhar_menu()
        self.main_loop()

    def desenhar_menu(self):

        for opcao in self.opcoes:
            text = self.myfont.render(str(self.posicao_seta + 1) + ".  " + opcao, True, self.cor_fonte)

            textrect = text.get_rect()
            textrect = textrect.move(self.x_pos,
                                     (self.tamanho_fonte / self.distancia * self.posicao_seta) + self.y_pos)
            self.screen.blit(text, textrect)
            self.amb.display.update(textrect)
            self.posicao_seta += 1

        self.posicao_seta = 0
        self.cursor = self.myfont.render(">", True, self.cor_seta)
        self.cursorrect = self.cursor.get_rect()
        self.cursorrect = self.cursorrect.move(self.x_pos - (self.tamanho_fonte // self.distancia),
                                               (self.tamanho_fonte // self.distancia * self.posicao_seta) + self.y_pos)

    def main_loop(self):
        seta_precionada = True
        sair_menu = False
        clock = self.amb.time.Clock()
        filler = self.amb.Surface.copy(self.screen)
        fillerrect = filler.get_rect()

        while not sair_menu:
            clock.tick(30)
            if seta_precionada == True:
                self.screen.blit(filler, fillerrect)
                self.amb.display.update(self.cursorrect)
                self.cursorrect = self.cursor.get_rect()
                self.cursorrect = self.cursorrect.move(self.x_pos - (self.tamanho_fonte // self.distancia),
                                                       (
                                                       self.tamanho_fonte // self.distancia * self.posicao_seta) + self.y_pos)
                self.screen.blit(self.cursor, self.cursorrect)
                self.amb.display.update(self.cursorrect)
                seta_precionada = False

            for event in self.amb.event.get():
                if event.type == self.amb.QUIT:
                    return -1
                if event.type == self.amb.KEYDOWN:
                    if event.key == self.amb.K_ESCAPE:
                        sair_menu = True
                    elif event.key == self.amb.K_1:
                        self.posicao_seta = 0;
                        seta_precionada = True;
                        sair_menu = True
                    elif event.key == self.amb.K_2 and len(self.opcoes) >= 2:
                        self.posicao_seta = 1;
                        seta_precionada = True;
                        sair_menu = True
                    elif event.key == self.amb.K_3 and len(self.opcoes) >= 2:
                        self.posicao_seta = 1;
                        seta_precionada = True;
                        sair_menu = True
                    elif event.key == self.amb.K_UP:
                        seta_precionada = True
                        if self.posicao_seta == 0:
                            self.posicao_seta = len(self.opcoes) - 1
                        else:
                            self.posicao_seta -= 1
                    elif event.key == self.amb.K_DOWN:
                        seta_precionada = True
                        if self.posicao_seta == len(self.opcoes) - 1:
                            self.posicao_seta = 0
                        else:
                            self.posicao_seta += 1
                    elif event.key == self.amb.K_KP_ENTER or \
                                    event.key == self.amb.K_RETURN:
                        sair_menu = True
