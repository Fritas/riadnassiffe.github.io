from usuario import Usuario

class Cliente(Usuario):

    def __init__(self, nome, idade, senha, cpf):
        Usuario.__init__(self, nome, idade, senha, cpf)
