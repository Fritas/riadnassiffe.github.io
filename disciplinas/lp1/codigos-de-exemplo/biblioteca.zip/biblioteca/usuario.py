from emprestimo import Emprestimo

class Usuario(object):

    multa = 0
    lista_de_emprestimo = []

    def __init__(self, nome, idade, senha, cpf):
        self.idade = idade
        self.nome = nome
        self.cpf = cpf
        self.senha = senha

    def alterar_senha(self, senha_velha, senha_nova):
        if self.senha == senha_velha:
            self.senha = senha_nova

    def imprimir_dados(self):
        print('nome='+self.nome+"  idade="+str(self.idade))

    def adicionar_multa(self, valor):
        self.multa += valor

    def registrar_emprestimo(self, livro, codigo_do_exemplar):
        self.lista_de_emprestimo.append(Emprestimo(livro, codigo_do_exemplar))

    def registrar_devolucao(self, titulo):
        for emprestimo in self.lista_de_emprestimo:
            if emprestimo.livro.titulo == titulo:
                emprestimo.finalizado = True
                return True
        return False

    def verificar_senha(self, senha):
        if self.senha == senha:
            return True
        else:
            return False
