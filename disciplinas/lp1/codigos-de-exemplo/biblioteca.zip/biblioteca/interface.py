from biblioteca import Biblioteca
import os
import time

def main():
    nome_biblioteca = input("Digite o nome da sua biblioteca")
    biblioteca = Biblioteca(nome_biblioteca)
    sair = False
    while(not sair):

        print("Menu")
        print("Para cadastrar usuário digite 1")
        print("Para cadastrar funcionário digite 2")
        print("Para cadastrar livro digite 3")
        print("Para cadastrar exemplar digite 4")
        print("Emprestar exemplar 5")
        print("Devolver exemplar 6")
        print("Sair 7")

        op = int(input("Digite a opção: "))

        if(op == 1):
            nome = input("Digite o nome: ")
            idade = input("Digite a idade: ")
            senha = input("Digite a senha : ")
            cpf = input("Digite o cpf: ")
            biblioteca.cadastrar_cliente(nome, idade, senha, cpf)
        elif(op == 2):
            nome = input("Digite o nome: ")
            idade = input("Digite a idade: ")
            senha = input("Digite a senha: ")
            cpf = input("Digite o cpf: ")
            cargo = input("Digite o cargo: ")
            salario = input("Digite o salario: ")
            biblioteca.cadastrar_funcionario(nome, idade, senha, cpf, cargo, salario)
        elif(op == 3):
            codigo_de_barra = input("Digite o codigo de barra: ")
            editora = input("Digite a editora: ")
            autor = input("Digite o autor: ")
            titulo = input("Digite o titulo: ")
            estante = input("Digite a estante: ")
            if biblioteca.cadastrar_livro(codigo_de_barra, editora, autor, titulo, estante):
                print("Cadastro realizado com sucesso")
            else:
                print("Falha ao cadastra o livro desejado")
        elif(op == 4):
            titulo = input("Digite o título : ")
            condicao = input("Digite a condicao: ")
            codigo_do_exemplar = input("Digite codigo do exemplar: ")
            if biblioteca.cadastrar_exemplar(titulo, condicao, codigo_do_exemplar):
                print("Cadastro realizado com sucesso")
            else:
                print("Falha ao cadastra o exemplar desejado")
        elif(op == 5):
            nome_fun = input("Digite o login do funcionario: ")
            senha_fun = input("Digite a senha do funcionario: ")
            nome = input("Digite o login do cliente: ")
            senha = input("Digite a senha do cliente: ")
            titulo = input("Digite título a ser empestado: ")
            data = input("Digite uma data: ")
            if biblioteca.emprestar(titulo, nome, senha, nome_fun, senha_fun, data):
                print("Emprestimo realizado com sucesso")
            else:
                print("Falha ao tentar realizar emprestimo")
        elif(op == 6):
            nome_fun = input("Digite o login do funcionario: ")
            senha_fun = input("Digite a senha do funcionario: ")
            nome = input("Digite o login do cliente: ")
            senha = input("Digite a senha do cliente: ")
            titulo = input("Digite título a ser empestado: ")
            data = input("Digite uma data:")
            if biblioteca.devolver(titulo, nome, senha, nome_fun, senha_fun, data):
                print("Emprestimo realizado com sucesso")
            else:
                print("Falha ao tentar realizar emprestimo")
        elif(op == 7):
            sair = True
        else:
            print("Você digitou uma opção inválida")

        time.sleep(3)
        os.system('clear')

if __name__ == '__main__':
    main()
