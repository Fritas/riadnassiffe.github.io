from exemplar import Exemplar

class Livro(object):

    lista_de_exemplares = []

    def __init__(self, codigo_de_barra, editora, lista_autores, titulo, estante):
        self.codigo_de_barra = codigo_de_barra
        self.editora = editora
        self.lista_autores = lista_autores
        self.titulo = titulo
        self.estante = estante

    def adicionar_exemplares(self, condicao, codigo_do_exemplar):
        self.lista_de_exemplares.append(Exemplar(self, condicao, codigo_do_exemplar))

    def remover_exemplares(self, codigo_do_exemplar):
        for exemplar in self.lista_de_exemplares:
            if exemplar.codigo_do_exemplar == codigo_do_exemplar:
                self.lista_de_exemplares.remove(exemplar)
                return True
        return False
