class Emprestimo:

    finalizado = False
    data_devolucao = ""

    def __init__(self, exemplar, data ):
        self.exemplar = exemplar
        self.data = data

    def devolver(self, data):
        self.data_devolucao = data
        self.finalizado = True
