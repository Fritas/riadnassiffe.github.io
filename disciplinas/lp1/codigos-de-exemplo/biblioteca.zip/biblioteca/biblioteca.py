from funcionario import Funcionario
from cliente import Cliente
from livro import Livro
from exemplar import Exemplar
from emprestimo import Emprestimo

class Biblioteca(object):
    lista_de_livros = []
    lista_de_usuarios = []
    quantidade_de_livros = 0
    quantidade_de_exemplares = 0

    def __init__(self, nome):
        self.nome = nome

    def cadastrar_funcionario(self, nome, idade, senha, cpf, cargo, salario):
        self.lista_de_usuarios.append(Funcionario(nome, idade, senha, cpf, cargo, salario))

    def cadastrar_cliente(self,nome, idade, senha, cpf):
        self.lista_de_usuarios.append(Cliente(nome, idade, senha, cpf))

    def buscar_livro(self, titulo):
        for livro in self.lista_de_livros:
            if livro.titulo == titulo:
                return livro
        return None

    def cadastrar_livro(self, codigo_de_barra, editora, lista_autores, titulo, estante):
        if self.buscar_livro(titulo) is None:
            self.lista_de_livros.append(Livro(codigo_de_barra, editora, lista_autores, titulo, estante))
            return True
        else:
            return False

    def cadastrar_exemplar(self, titulo, condicao, codigo_do_exemplar):
        livro = self.buscar_livro(titulo)
        if livro is not None:
            livro.adicionar_exemplares(condicao, codigo_do_exemplar)
            return True
        else:
            return False

    def verificar_usuario(self, nome, senha):
        for usuario in self.lista_de_usuarios:
            if usuario.nome == nome:
                if usuario.verificar_senha(senha):
                    return True
                else:
                    return False

        return False

    def emprestar(self, titulo, nome, senha, nome_fun, senha_fun, data):
        if self.verificar_usuario(nome, senha) and self.verificar_usuario(nome_fun, senha_fun):
            livro = self.buscar_livro(titulo)
            if livro is not None:
                for exemplar in livro.lista_de_exemplares:
                    if exemplar.disponivel:
                        exemplar.trocar_disponibilidade()
                        for usuario in self.lista_de_usuarios:
                            if usuario.nome == nome:
                                usuario.lista_de_emprestimo.append(Emprestimo(exemplar, data))
                                return True
        return False

    def devolver(self, titulo, nome, senha, nome_fun, senha_fun, data):
        if self.verificar_usuario(nome, senha) and self.verificar_usuario(nome_fun, senha_fun):
            for usuario in self.lista_de_usuarios:
                if usuario.nome == nome:
                    for emprestimo in usuario.lista_de_emprestimo:
                        if emprestimo.exemplar.livro.nome == titulo:
                            emprestimo.exemplar.trocar_disponibilidade()
                            emprestimo.devolver(data)
                            return True
                    return False
        return False
