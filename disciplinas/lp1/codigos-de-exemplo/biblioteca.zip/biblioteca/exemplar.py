class Exemplar(object):

    disponivel = True

    def __init__(self, livro, condicao, codigo_do_exemplar):
        self.condicao = condicao
        self.codigo_do_exemplar = codigo_do_exemplar
        self.livro = livro

    def trocar_disponibilidade(self):
        self.disponivel = not self.disponivel

    def trocar_condicao(self, condicao):
        self.condicao = condicao
