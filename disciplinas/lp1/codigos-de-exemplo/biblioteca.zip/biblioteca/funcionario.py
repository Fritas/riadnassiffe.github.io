from usuario import Usuario

class Funcionario(Usuario):

    def __init__(self, nome, idade, senha, cpf, cargo, salario):
        Usuario.__init__(self, nome, idade, senha, cpf)
        self.salario = salario
        self.cargo = cargo
