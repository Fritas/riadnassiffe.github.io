class Mamifero(object):
    def __init__(self, idade, peso, nome):
        self.idade = idade
        self.peso = peso
        self.nome = nome

    def comer(self):
        print("Comendo")

    def locomover(self):
        print("Se locomovendo")

    def retornar_idade(self):
        return self.idade

    def faz_barulho(self):
        pass


if __name__ == "__main__":
    m = Mamifero(10, 5, "bob", 6)
    m.comer()
    m.locomover()
    m.faz_barulho()
