from info201.heranca.mamifero import Mamifero


class Gato(Mamifero):
    def __init__(self, peso, idade, nome, pelagem, raca, num_patas):
        Mamifero.__init__(self, idade, peso, nome)
        self.num_patas = num_patas
        self.raca = raca
        self.pelagem = pelagem

    def faz_barulho(self):
        print("Miau")

    def retornar_informacao_sobre_pelos(self):
        return self.pelagem


if __name__ == "__main__":
    c = Gato(8, 5, 'Misse', 12, 'pequena', 6, 5)
    c.comer()
    c.locomover()
    c.faz_barulho()
    print(c.retornar_idade())
