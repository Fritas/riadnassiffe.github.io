from info201.heranca.mamifero import Mamifero


class Cachorro(Mamifero):
    def __init__(self, idade, peso, nome, raca, porte, num_patas):
        Mamifero.__init__(self, idade, peso, nome)
        self.raca = raca
        self.porte = porte
        self.num_patas = num_patas

    def locomover(self, tipo_de_andar):
        print("Andar do cachorro " + str(tipo_de_andar))

    def faz_barulho(self):
        print("Au au")


if __name__ == "__main__":
    c = Cachorro(8, 5, 'Bob', 'vira lata', 'pequeno', 3)
    c.comer()
    c.locomover("correndo")
    c.faz_barulho()
    print(c.retornar_idade())
