from info201.heranca.cachorro import Cachorro
from info201.heranca.gato import Gato

from info201.heranca.alien import Alien


class Clinica(object):
    lista_pacientes = []

    def adicionar_animal(self, animal):
        self.lista_pacientes.append(animal)

    def listar_pacientes(self):
        for animal in self.lista_pacientes:
            animal.faz_barulho()
            print(animal.nome)


if __name__ == "__main__":
    clinica = Clinica()

    c = Cachorro(8, 5, 'Bob', 'vira lata', 'pequeno', 3)
    g = Gato(8, 5, 'Misse', 12, 'pequena', 5)
    a = Alien(12, 5, 'ET', 'marciano', 'normal', 10)

    clinica.adicionar_animal(g)
    clinica.adicionar_animal(c)
    clinica.adicionar_animal(g)
    clinica.adicionar_animal(a)
    clinica.adicionar_animal(g)
    clinica.adicionar_animal(c)
    clinica.adicionar_animal(g)
    clinica.adicionar_animal(a)
    clinica.adicionar_animal(g)
    clinica.adicionar_animal(g)

    clinica.listar_pacientes()
