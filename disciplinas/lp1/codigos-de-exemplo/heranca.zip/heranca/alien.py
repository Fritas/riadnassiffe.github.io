from info201.heranca.cachorro import Cachorro
from info201.heranca.gato import Gato


class Alien(Cachorro, Gato):
    def __init__(self, idade, peso, nome, raca, porte, num_patas):
        Cachorro.__init__(self, idade, peso, nome, raca, porte, \
                          num_patas)
        Gato.__init__(self, peso, idade, nome, 12, raca, num_patas)

    def faz_barulho(self):
        print("ET")


if __name__ == "__main__":
    a = Alien(12, 5, 'ET', 'marciano', 'normal', 10)
    print(a.num_mamas)
