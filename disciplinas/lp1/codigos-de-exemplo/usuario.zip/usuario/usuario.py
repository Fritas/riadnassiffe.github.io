class Usuario(object):
    def __new__(cls, nome, senha):
        if nome == "Ríad":
            return None
        else:
            result = super(Usuario, cls).__new__(cls)
            return result

    def __init__(self, nome_usuario, senha):
        self.nome_usuario = nome_usuario
        self.senha = senha

    def autenticar(self, nome_usuario, senha):
        if self.senha == senha and self.nome_usuario == nome_usuario:
            return True
        else:
            return False
