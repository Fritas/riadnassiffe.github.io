import random

from info202.usuario import Usuario


class Disciplina():
    def __init__(self, nome, carga_horaria):
        self.nome = nome
        self.carga_horaria = carga_horaria
        self.notas = []

    def definir_nota(self, nota):
        self.notas.append(nota)


class Aluno(Usuario):
    def __init__(self, nome_usuario, senha):
        super(Aluno, self).__init__(nome_usuario, senha)
        self.lista_de_disciplinas = []

    def matricular_em_disciplina(self, disciplina):
        self.lista_de_disciplinas.append(disciplina)

    def gerar_lista_de_frequencia(self):
        for disciplina in self.lista_de_disciplinas:
            self.dic

    def ver_notas(self):
        for disciplina in self.lista_de_disciplinas:
            print("Notas:", disciplina.notas)
            print("Média", sum(disciplina.notas) / len(disciplina.notas))


class Professor(Usuario):
    def __init__(self, nome_usuario, senha):
        super(Professor, self).__init__(nome_usuario, senha)
        self.lista_de_disciplinas = []

    def definir_notas(self, aluno):
        for disciplina in aluno.lista_de_disciplinas:
            if disciplina in self.lista_de_disciplinas:
                disciplina.definir_nota(random.randint(0, 10))
