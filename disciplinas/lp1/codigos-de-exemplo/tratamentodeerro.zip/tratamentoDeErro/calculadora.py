import math


class NumNeg(Exception):
    pass


class Calculadora():
    def obter_numero(self, mensagem):
        errou = True
        while errou:
            try:
                num = float(input(mensagem))
                errou = False
            except ValueError:
                print('Você digitou um valor inválido..')
                errou = True
        return num

    def divisao(self):
        fim = True
        while fim:
            try:
                a = self.obter_numero("digite o valr a")
                b = self.obter_numero("digite o valr b")

                resultado = a / b
                fim = False
            except ZeroDivisionError:
                print('Digite novos valores para as variáveis a e b, b não pode ser ZERO')
                fim = True

    def raiz_quadrada(self):
        fim = True
        while fim:
            try:
                a = self.obter_numero("digite o valr a")

                if a < 0:
                    raise NumNeg()

                resultado = math.sqrt(a)
                print(resultado)
                fim = False
            except NumNeg:
                print('a não pode ser negativo')
                fim = True


if __name__ == "__main__":
    c = Calculadora()
    c.raiz_quadrada()
