class carro:

    def __init__(self, consumoPorKm):
        self.consumoPorKm = consumoPorKm
        self.quantidadeCombustivel = 0

    def andar(self, distancia):
        consumo = distancia*self.consumoPorKm
        if consumo <= self.quantidadeCombustivel:
            self.quantidadeCombustivel -= consumo
            return True
        return False

    def obterGasolina(self):
        return self.quantidadeCombustivel

    def adicionarGasolina(self, quantidade):
        if quantidade >0:
            self.quantidadeCombustivel += quantidade
