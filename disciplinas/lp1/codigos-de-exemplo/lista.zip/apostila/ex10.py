class BombaDeCombustivel:

    def __init__(self, tipoCombustivel, valorLitro, quantidadeCombustivel):
        self.tipoCombustivel = tipoCombustivel
        self.valorLitro = valorLitro
        self.quantidadeCombustivel = quantidadeCombustivel

    def abastecerPorValor(self, valor):
        quantidade = valor/self.valorLitro
        if quantidade >= self.quantidadeCombustivel:
            self.quantidadeCombustivel -= quantidade
            return quantidade
        return self.quantidadeCombustivel - quantidade

    def abastecerPorLitro(self, quantidade):
        if quantidade >= self.quantidadeCombustivel:
            self.quantidadeCombustivel -= quantidade
            return quantidade*self.valorLitro
        return self.quantidadeCombustivel - quantidade

    def alterarValor(self, valor):
        self.valorLitro = valor

    def alterarCombustivel(self, tipo):
        tipos = ["gasolina", "alcool", "disel"]
        if tipo in tipos:
            self.tipoCombustivel = tipo

    def alterarQuantidadeCombustivel(self, quantidadeCombustivel):
        if quantidadeCombustivel > 0:
            self.quantidadeCombustivel = quantidadeCombustivel
