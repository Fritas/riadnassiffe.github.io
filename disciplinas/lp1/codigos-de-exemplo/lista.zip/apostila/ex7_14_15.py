class Tamagushi:
    def __init__(self, nome):
        self.nome = nome
        self.nivelDeFome = 0
        self.saude = 100
        self.idade = 0
        self.tedio = 0

    def alterarNome(self, nome):
        self.nome = nome

    def alterarSaude(self, saude):
        if saude<=100 and saude>=0:
            self.saude = saude
            return True
        return False

    def alterarFome(self, fome):
        if fome<=100 and fome>=0:
            self.nivelDeFome = fome
            return True
        return False

    def incrementarIdade(self):
        self.idade+=1

    def retornarHumor(self):
        if self.nivelDeFome != 0:
            return (1/self.nivelDeFome + self.saude/100)/2
        else:
            return (1+self.saude/100)/2


class BichinhoPlusPlus(Tamagushi):

    def __init__(self, nome):
        Tamagushi.__init__(self, nome)

    def alimentar(self, quantidade):
        if self.nivelDeFome -quantidade >= 0:
            self.nivelDeFome -= quantidade
        else:
            self.nivelDeFome = 0

    def brincar(self):
        if self.tedio>0:
            self.tedio -=1

    def curar(self):
        if self.saude <= 93:
            self.saude +=7
        else:
            self.saude = 100


    def aumentarTedio(self):
        if self.tedio<100:
            self.tedio +=1

    def __str__(self):
        return "Nome"+self.nome +"\n Idade:"+str(self.idade)+"\n Saúde"+str(self.saude)+"\n Nível de Fome:"+str(self.nivelDeFome)

if __name__ == '__main__':
    nome = input("Qual o nome do Tamagushi?: ")
    bichinho =  BichinhoPlusPlus(nome)
    vivo = True
    tempoBrincar = 0
    while(vivo):
        print("Alimentar:1")
        print("Curar:2")
        print("Aumentar idade:3")
        print("Brincar:4")
        print("acelerar:5")

        opcao = input("Digite uma das opções acima:")

        if opcao == '1':
            quantidade = int(input("O quanto de comida você deseja usar? "))
            bichinho.alimentar(quantidade)
        elif opcao == '2':
            bichinho.curar()
        elif opcao == '3':
            bichinho.incrementarIdade()
        elif opcao == '4':
            tempoBrincar = int(input("Quanto tempo você deseja brincar? "))
        elif opcao == '5':
            for i in range(1,101):
                bichinho.alimentar(-1)
                bichinho.aumentarTedio()
        elif opcao == "status":
            print(bichinho)

        if tempoBrincar > 0:
            bichinho.brincar()

        bichinho.alimentar(-1)
        bichinho.aumentarTedio()
        if bichinho.nivelDeFome > 100 or bichinho.saude <= 0:
            vivo = False
            print(bichinho.nome," morreu")
