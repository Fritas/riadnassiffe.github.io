class Ponto:

    def __init__(self, x, y):
        self.x = x
        self.y = y

    def imprimir_ponto(self):
        print("("+str(self.x)+", "+str(self.y)+")")

    def __str__(self):
        return "("+str(self.x)+", "+str(self.y)+")"


class Retangulo:

    def __init__(self, altura, largura, vertice_de_partida):
        self.altura = altura
        self.largura = largura
        self.vertice_de_partida = vertice_de_partida  # é considerado como vertice de partida o ponto inferior esquerdo.

    def calcular_centro(self):
        x = self.largura/2 + self.vertice_de_partida.x
        y = self.altura/2 + self.vertice_de_partida.y
        return Ponto(x, y)

    def alterar_dimensoes(self, altura, largura):
        self.altura = altura
        self.largura = largura


if __name__ == '__main__':
    largura = float(input("entre com um valor para largura: "))
    altura = float(input("entre com um valor para altura: "))
    x = float(input("entre com um valor de x para o vertice de partida: "))
    y = float(input("entre com um valor de y para o vertice de partida: "))
    r = Retangulo(altura, largura, Ponto(x, y))
    print("O centro do retangulo é " + str(r.calcular_centro()))
    sair = False
    while(not sair):
        print("1 - Para sair")
        print("2 - Digitar nova algura e largura")
        print("3 - Imprimir o ponto do centro do retangulo")
        op = input('Digite uma opção ')
        if op == "1":
            sair = True
        elif op == "2":
            largura = float(input("entre com um valor para largura: "))
            altura = float(input("entre com um valor para altura: "))
            r.alterar_dimensoes(altura, largura)
        elif op == "3":
            print("O centro do retangulo é " + str(r.calcular_centro()))
        else:
            print("Opção inválida tento outra")
