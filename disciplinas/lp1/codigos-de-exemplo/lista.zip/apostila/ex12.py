from ex5 import ContaCorrente

class ContadeInvestimento(ContaCorrente):

    def __init__(self, numero, correntista, taxaDejuros, saldo):
        ContaCorrente.__init__(self, numero, correntista, saldo)
        self.taxaDejuros = taxaDejuros

    def adicioneJuros(self):
        self.saldo += self.saldo * self.taxaDejuros


if __name__ == '__main__':
    c = ContadeInvestimento(1, 'Pedro', 0.1, 1000)
    for i in range(5):
        c.adicioneJuros()
    print(c.saldo)
