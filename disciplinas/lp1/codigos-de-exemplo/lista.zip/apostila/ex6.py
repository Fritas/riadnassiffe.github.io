class Tv:

    def __init__(self, vol_min, vol_max, canal_min, canal_max):
        self.vol_min = vol_min
        self.vol_max = vol_max
        self.canal_min = canal_min
        self.canal_max =canal_max
        self.vol = vol_min
        self.canal = canal_max

    def trocar_canal(self, canal):
        if self.canal_min <= canal and self.canal_max >= canal:
            self.canal = canal
            return True
        return False

    def trocar_volume(self, volume):
        if self.vol_min <= volume and self.vol_max >= volume:
            self.volume = volume
            return True
        return False
