class Funcionario:

    def __init__(self, nome, salario):
        self.nome = nome
        self.salario = salario

    def get_nome(self):
        return self.nome

    def get_salario(self):
        return self.salario

    def aumentarSalario(self, percenteual):
        self.salario += self.salario * percenteual/100.0

if __name__ == '__main__':
    f = Funcionario("Pedro", 1000)
    print(f.get_nome())
    print(f.get_salario())
    f.aumentarSalario(10.0)
    print(f.get_salario())
