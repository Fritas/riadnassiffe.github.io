class Quadrado:

    def __init__(self, lado):
        self.lado = lado

    def modificarLado(self, lado):
        self.lado = lado

    def retornarLado(self):
        return self.lado

    def calcularArea(self):
        return self.lado**2 # ou self.lado * self.lado
