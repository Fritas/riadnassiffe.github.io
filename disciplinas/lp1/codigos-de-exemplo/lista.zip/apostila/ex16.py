from ex7_14_15 import BichinhoPlusPlus
import random


class Fazenda:

    def __init__(self):
        self.lista_de_bichos = []

    def adicionar_bicho(self, nome):
        b = BichinhoPlusPlus(nome)
        b.alterarFome(random.randint(1, 100))
        b.tedio = random.randint(1, 100)
        self.lista_de_bichos.append()

    def jogar(sef):
        tempoBrincar = 0
        while(len(self.lista_de_bichos) > 0):
            print("Adicionar Bicho:0")
            print("Alimentar:1")
            print("Curar:2")
            print("Aumentar idade:3")
            print("Brincar:4")
            print("acelerar:5")

            opcao = input("Digite uma das opções acima: ")

            if opcao == '0':
                nome = input("Digite um nome para o bicho ")
                self.adicionar_bicho(nome)
            if opcao == '1':
                quantidade = int(input("O quanto de comida você deseja usar? "))
                for bichinho in self.lista_de_bichos:
                    bichinho.alimentar(quantidade)
            elif opcao == '2':
                for bichinho in self.lista_de_bichos:
                    bichinho.curar()
            elif opcao == '3':
                for bichinho in self.lista_de_bichos:
                    bichinho.incrementarIdade()
            elif opcao == '4':
                tempoBrincar = int(input("Quanto tempo você deseja brincar? "))
            elif opcao == '5':
                for i in range(1, 101):
                    for bichinho in self.lista_de_bichos:
                        bichinho.alimentar(-1)
                        bichinho.aumentarTedio()
            elif opcao == "status":
                for bichinho in self.lista_de_bichos:
                    print(bichinho)

            if tempoBrincar > 0:
                for bichinho in self.lista_de_bichos:
                    bichinho.brincar()
            for bichinho in self.lista_de_bichos:
                bichinho.alimentar(-1)
                bichinho.aumentarTedio()

            for bichinho in self.lista_de_bichos:
                if bichinho.nivelDeFome > 100 or bichinho.saude <= 0:
                    print(bichinho.nome," morreu")
                    self.lista_de_bichos.remove(bichinho)
