class Macaco:

    def __init__(self, nome):
        self.nome = nome
        self.bucho =[]

    def comer(self, comida):
        self.bucho.append(comida)

    def verBucho(self):
        return self.bucho

    def digerir(self):
        if len(self.bucho) > 0:
            self.bucho.remove(self.bucho[0])

    def __str__(self):
        return self.nome

if __name__ == "__main__":
    m1 = Macaco("m1")
    m2 = Macaco("m2")

    m1.comer("Uva")
    m1.comer("Pedra")
    m1.comer("Jambo")
    m2.comer("Banana")
    print(m1.verBucho())
    print(m2.verBucho())

    m1.comer(m2)
    for comida in m1.verBucho():
        print(comida)
