class ContaCorrente:

    def __init__(self, numero, correntista, saldo=0):
        self.numero = numero
        self.correntista = correntista
        self.saldo = saldo

    def alterarNome(self, nome):
        self.correntista = correntista

    def deposito(self, valor):
        if valor>0:
            self.saldo +=valor
            return True
        return False

    def saque(self, valor):
        if valor >0:
            self.saldo -=valor
            return True
        return False
