class Retangulo:

    def __init__(self, ladoA, ladoB):
        self.ladoA = ladoA
        self.ladoB = ladoB

    def modificarLados(self, ladoA, ladoB):
        self.ladoA = ladoA
        self.ladoB = ladoB

    def returnLados(self):
        return (self.ladoA, self.ladoB)

    def calcularPerimetro(self):
        return 2*self.ladoA + 2*self.ladoB

    def calcularArea(self):
        return self.ladoA * self.ladoB



if __name__ == '__main__':
    ladoA = float(input("digite o lado A: "))
    ladoB = float(input("digite o lado B: "))

    local = Retangulo(ladoA, ladoB)

    ladoA = float(input("digite o lado A do piso: "))
    ladoB = float(input("digite o lado B do piso: "))

    piso = Retangulo(ladoA, ladoB)

    area_local = local.calcularArea()
    area_piso = piso.calcularArea()

    quantidade_de_piso = area_local//area_piso
    if area_local%area_piso != 0:
        quantidade_de_piso +=1

    quantidade_de_rodape = local.calcularPerimetro()
    print("Quantidade de pisos igual a ",quantidade_de_piso)
    print("Serão necessários "+str(quantidade_de_rodape)+" unidades de rodape")
