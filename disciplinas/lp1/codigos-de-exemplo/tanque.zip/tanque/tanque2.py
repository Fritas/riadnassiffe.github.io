from info202.tanque import Tanque


class Tanque2(Tanque):
    def __init__(self, dano, vida, cordx, cordy):
        super(Tanque2, self).__init__(dano, vida, cordx, cordy)

    def mover(self, nova_cordx, nova_cordy):
        """
        askjd haksjdh aksjdh aksdha klsdjh alksdjhf aksdfh
        """
        if self.vida > 0:  # essa condicao verifica se o tanque esta vivo
            if abs(nova_cordx - self.cordx) + abs(nova_cordy - self.cordy) < 2:
                self.cordx = nova_cordx
                self.cordy = nova_cordy
                return True
        return False

    def atacar(self, cordx_ataque, cordy_ataque, tanque):
        """
        asdjhf aksjhf lakj
        """
        if self.vida > 0 and tanque.vida > 0:
            if tanque.cordx == cordx_ataque and tanque.cordy == cordy_ataque:
                tanque.vida = tanque.vida - self.dano
                return True
        return False
