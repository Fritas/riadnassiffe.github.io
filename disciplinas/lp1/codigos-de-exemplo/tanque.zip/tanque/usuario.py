"""

"""

class Usuario:
    """
    """
    def __init__(self, nome, idade, tanque):
       """
       """
       self.nome = nome
       self.idade = idade
       self.tanque = tanque

    def jogar(self, posX, posY, usuario=None):
        """
        """
        if self.existeTanque():
            if usuario is not None:
                return self.tanque.atacar(posX, posY, usuario.tanque)
            return self.tanque.mover(posX, posY)

    def existeTanque(self):
        """
        """
        if self.tanque.vida > 0:
            return True
        else:
            return False
