from mapa import Mapa
from tanque import Tanque
from tanque2 import Tanque2

from info202.usuario import Usuario


class Tabuleiro:
    """
    """
    def __init__(self, tamanho_x, tamanho_y):
        self.mapa = Mapa(tamanho_x, tamanho_y)
        self.lista_de_jogadores = []

    def inicializar_jogador(self):
        nome = input("Qual seu nome?")
        idade = int(input("Qual a sua idade?"))
        tipo_de_tanque = int(input("Qual tipo de tanque você quer?"))
        coord = False
        while not coord:
            x = int(input("Qual a coordenada x do seu tanque?"))
            y = int(input("Qual a coordenada y do seu tanque?"))
            if self.mapa.validar_coordenada(x, y):
                coord = True
            else:
                print("Digite novamente as coordenadas")
        if tipo_de_tanque == 1:
            t = Tanque(20, 25, x, y)
        else:
            t = Tanque2(20, 25, x, y)
        u = Usuario(nome, idade, t)
        return u

    def inicializar_jogo(self):
        num_jogadores = int(input("Digite quantas pessoas vão jogar:"))
        for i in range(num_jogadores):
            self.lista_de_jogadores.append(self.inicializar_jogador())

    def jogar_rodada(self, jogador):
        acao = input("O que você deseja fazer?(a - atacar/m - mover)")
        if acao == "a":
            x = int(input("Qual a coordenada x você deseja atacar?"))
            y = int(input("Qual a coordenada y você deseja atacar?"))
            for adversario in self.lista_de_jogadores:
                if jogador is not adversario:
                    if jogador.jogar(x, y, adversario):
                        print("Você atacou o jogador " + adversario.nome)
                        print("A vida atual de " + adversario.nome + " é " \
                              + str(adversario.tanque.vida) + "pontos de vida")
        elif acao == "m":
            x = int(input("Qual a coordenada x você deseja atacar?"))
            y = int(input("Qual a coordenada y você deseja atacar?"))
            jogador.jogar(x, y)

    def verificar_fim(self):
        cont = 0
        for jogador in self.lista_de_jogadores:
            if jogador.existeTanque():
                cont += 1
                if cont > 1:
                    return True
        return False

    def iniciar_jogo(self):
        print("Inicializando o jogo")
        while self.verificar_fim():
            for jogador in self.lista_de_jogadores:
                if jogador.existeTanque():
                    self.jogar_rodada(jogador)

        for jogador in self.lista_de_jogadores:
            if jogador.existeTanque():
                print(jogador.nome +  " venceu!!! :))))")

if __name__ == "__main__":
    tabuleiro = Tabuleiro(10, 10)
    tabuleiro.inicializar_jogo()
    tabuleiro.iniciar_jogo()
