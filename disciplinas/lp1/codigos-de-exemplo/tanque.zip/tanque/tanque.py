"""
Este modulo deve .....
"""
from random import randint


class Tanque(object):
    """
    Esta classe representa um tanque no jogo que vamos implementar em sala
    de aula
    """

    def __init__(self, dano, vida, cordx, cordy):
        """
        Esse metodo inicializa os parametros do tanque
        :param dano: indica o dano que tanque ira causar no seu alvo
        :param vida: representa os pontos de vida do tanque e caso o programador
        nao informe um valor ele sera igual a 100
        """
        self.vida = vida
        self.cordx = cordx
        self.cordy = cordy
        self.dano = dano

    def mover(self, nova_cordx, nova_cordy):
        """
        askjd haksjdh aksjdh aksdha klsdjh alksdjhf aksdfh
        """
        if self.vida > 0:  # essa condicao verifica se o tanque esta vivo
            self.cordx = nova_cordx
            self.cordy = nova_cordy
            return True
        return False

    def atacar(self, cordx_ataque, cordy_ataque, tanque):
        """
        asdjhf aksjhf lakj
        """
        if self.vida > 0 and tanque.vida > 0:
            if tanque.cordx == cordx_ataque and tanque.cordy == cordy_ataque:
                tanque.vida = tanque.vida - randint(1, self.dano)
                return True
        return False
